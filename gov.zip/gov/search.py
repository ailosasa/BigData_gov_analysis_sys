#!/usr/bin/python3
import pymysql
# 打开数据库连接
db = pymysql.connect("localhost", "root", "root", "GOVDATA", charset='utf8')
# 使用cursor()方法获取操作游标
cursor = db.cursor()
time1='2018-9-10'
time2='2018-9-20'
sql = "SELECT * FROM event \
           WHERE rec_id < 100000 and CREATE_TIME BETWEEN str_to_date(\'%s\','%%Y-%%m-%%d %%H:%%i:%%s') AND str_to_date(\'%s\','%%Y-%%m-%%d %%H:%%i:%%s')" % (time1, time2)

try:
    # 执行SQL语句
    cursor.execute(sql)
    # 获取所有记录列表
    results = cursor.fetchall()
    for result in results:
        print(result[0])
except:
    print("Error: unable to fetch data")

# 关闭数据库连接
db.close()
