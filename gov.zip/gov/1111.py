#!/usr/bin/python
# -*- coding: UTF-8 -*-

import data
data.load()
result=data.search('2018-07-04 17:24:41', '2018-07-12 17:24:41')